using namespace std;
#include <string>
#include <iostream>
#include "Point.h"
#include "Line.h"
#include "GraphicElement.h"
#include "VectorGraphic.h"

VectorGraphic Image;

void VectorGraphic::AddGraphicElement(){
	int size = 0;
	char* name;
	int lineNum = 0;
	int x, y;
	
	GraphicElement *graphic = new GraphicElement();
	Line *pLines;
	for (int i = 0; i < numGraphicElements; i++){
		graphic = graphic[i]+pElements[i];
	}
	delete pElements;
	pElements = graphic;
	cout << "Adding A Graphic Element\n" << endl;
	numGraphicElements++;
	cout << "Please enter the name of the new GraphicElement(<256 characters): ";
	cin >> name;
	cout << "How many lines are there in the  new GraphicElement?";
	cin >> lineNum;
	size = lineNum - 1;
	
	for (int j = 0; j < size; j++){
		cout << endl << "Please enter the x coord of the start point of line index " << j << ": ";
		cin >> x;
		cout << endl << "Please enter the y coord of the start point of line index " << j << ": ";
		cin >> y;
		Point point(x, y);
		cout << endl << "Please enter the x coord of the end point of line index " << j << ": ";
		cin >> x;
		cout << endl << "Please enter the y coord of the end point of line index " << j << ": ";
		cin >> y;
		Point secPoint(x, y);

		pLines = new Line(point, secPoint);
	}
	pElements = new GraphicElement(pLines,name,lineNum);
	

}
void VectorGraphic::DeleteGraphicElement(){
	int index = 0;
	GraphicElement *graphic = new GraphicElement();
	cout << "Deleting a Graphic Element" << endl;
	cout << "Please enter the index of the Graphic Element you wish to delete" << endl;
	cin >> index;
	for (int i = 0; i < index; i++){
		graphic = graphic[i]+pElements[i];
	}
	for (int i = 0; i < numGraphicElements-1; i++){
		graphic = graphic[i]+pElements[i+1];
	}
	numGraphicElements--;
	delete[]pElements;
	pElements = graphic;

}
void VectorGraphic :: operator+=(GraphicElement &temp){
	
	GraphicElement *tempElements = new GraphicElement[numGraphicElements + 1];
	for(int i = 0; i < numGraphicElements; i++){
		tempElements[i] = pElements[i];
	}
	tempElements[numGraphicElements] = temp;
}
GraphicElement & VectorGraphic::operator[](int index){
	return pElements[index];
}

ostream & operator<<(ostream& os, VectorGraphic & vector){
	os << "Reporting Graphic Element:" << vector.numGraphicElements;
	cout << Image;
	return os;
}


